#!/usr/bin/env python

from bs4 import BeautifulSoup

def pulltext(filename):    
    text = []
    soup = BeautifulSoup(open(filename,"r+"))
    textversion = open(filename+".txt","w")
    for p in soup.find_all('p'):
        if p.attrs == {'align': 'left', 'class': ['style2']}:
            string = p.string
            stringa = string.replace("\n                      ", " ")
            stringb = stringa.replace("\n                    ", " ")
            stringc = stringb.replace(" (Laughter.) ", " ")
            stringd = stringc.replace(" (laughter) ", " ")
            stringe = stringd.replace("(Applause.)", "")
            stringf = stringe.replace("(Laughter.)", "")
            stringg = stringf.replace("(laughter.)", "")
            text.append(stringg)
    textversion.write(''.join(text))
    textversion.close()


